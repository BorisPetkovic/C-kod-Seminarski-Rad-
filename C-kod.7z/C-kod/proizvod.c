#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <time.h>
int A[500][500];
int B[500][500];
int C[500][500];

int random(int a,int b)
{
    return (rand()%(b-a+1)+a);
}

void create(int m,int n,int mat[m][n],int procMin,int procMax)
{
int indikator;
float procenat1;
float procenat2;



   int suma = 0;
    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
        mat[i][j] = random(0,1);
        if(mat[i][j] == 0){suma++;}
        }


    }

    float procenat = (float)suma / (m*n) *100;


         if(procenat < procMin)
 {   do{
     int x = random(0,m);
     int y = random(0,n);
     if(mat[x][y] == 1)
     {
         mat[x][y] = 0;
         suma++;
     }
     procenat1 = (float)suma / (m*n)*100;
 }while(procenat1<procMin);
     }

            if(procenat > procMax)
 {
  do{
     int x = random(0,m);
     int y = random(0,n);
     if(mat[x][y] == 0)
     {
         mat[x][y] = 1;
         suma--;
     }
     procenat2 = (float)suma / (m*n)*100;
 }while(procenat2>procMax);
     }
     }

int proizvod(int m,int n,int p,int A[m][n],int B[n][p],int C[m][p])
{
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<p;j++)
        {int pv = 0;
          for(int k=0;k<n;k++)
          {
              pv += A[i][k] * B[k][j];


          }
           C[i][j] = pv;
        }
    }
}
void ispisMat(int m,int n,int mat[m][n])
{
    for(int i =0;i<m;i++){
        for(int j=0;j<n;j++){
          printf("%d  ",mat[i][j]);

        }
        printf("\n");
    }

}
int main()
{srand ( time(0));

    int n=500;
    int m=500;
    int p=500;

    create(m,n,A,90,98);
     //ispisMat(m,n,A);
  printf("\n");
    create(m,n,B,90,98);
//ispisMat(n,p,B);
    // printf("\n");

     proizvod(m,n,p,A,B,C);

     //ispisMat(m,p,C);



    return 0;

}
