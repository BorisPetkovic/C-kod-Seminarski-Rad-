#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <time.h>

int mat[500][500];
int mat2[500][500];
int A[6000000],IA[6000000],JA[6000000];
int A1[6000000],IA1[6000000],JA1[6000000];
int A2[6000000],IA2[6000000],JA2[6000000];


int randomm(int a,int b)
{
    return (rand()%(b-a+1)+a);
}

void create(int m,int n,int mat[m][n],int procMin,int procMax)
{
int indikator;
float procenat1;
float procenat2;



   int suma = 0;
    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
        mat[i][j] = randomm(0,1);
        if(mat[i][j] == 0){suma++;}
        }


    }

    float procenat = (float)suma / (m*n) *100;


         if(procenat < procMin)
 {   do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 1)
     {
         mat[x][y] = 0;
         suma++;
     }
     procenat1 = (float)suma / (m*n)*100;
 }while(procenat1<procMin);
     }

            if(procenat > procMax)
 {
  do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 0)
     {
         mat[x][y] = 1;
         suma--;
     }
     procenat2 = (float)suma / (m*n)*100;
 }while(procenat2>procMax);
     }
     }

void transformToCRS(int m,int n,int mat[m][n],int A[], int IA[], int JA[])
{   int k =0;

    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(mat[i][j] != 0)
            {
                A[k] = mat[i][j];

                IA[k] = i;
                JA[k] = j;
                k++;

            }
        }
    }

   /* for(int l =0;l<k;l++)
    {
        printf("A[%d]=%d  ",l,A[l]);

    }
    printf("\n");
      for(int l1 =0;l1<k;l1++)
    {
        printf("IA[%d]=%d  ",l1,IA[l1]);

    }
 printf("\n");
      for(int l2 =0;l2<k;l2++)
    {
        printf("JA[%d]=%d  ",l2,JA[l2]);

    }
    printf("\n");*/


}

    int brojJedinica(int m,int n,int mat[m][n])
{   int k =0;

    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(mat[i][j] != 0)
            {
                k++;

            }
        }
    }
return k;}


/*void ispisMat(int m,int n,int mat[m][n])
{
    for(int i =0;i<m;i++){
        for(int j=0;j<n;j++){
          printf("%d  ",mat[i][j]);

        }
        printf("\n");
    }

}*/

void sumaCSR(int A1[],int IA1[],int JA1[],int A2[],int IA2[],int JA2[],int A[],int IA[],int JA[],int k1,int k2)
{int j=0;
int i=0;
int x=0;
int z=0;
int indikator = 0;
    while(indikator == 0)
    {while(z==0){


    if(IA1[i]<IA2[j])
        {
            A[x] = A1[i];
            IA[x] = IA1[i];
            JA[x] = JA1[i];

                i++;
            //printf("%d %d %d\n",A[x],IA[x],JA[x]);
            break;

        }

         if(IA1[i]==IA2[j] && JA1[i]<JA2[j])
        {
            A[x] = A1[i];
            IA[x] = IA1[i];
            JA[x] = JA1[i];

                i++;
           // printf("%d %d %d\n",A[x],IA[x],JA[x]);
            break;


        }

         if(IA1[i]==IA2[j] && JA1[i]>JA2[j])
        {
            A[x] = A2[j];
            IA[x] = IA2[j];
            JA[x] = JA2[j];
            j++;

           // printf("%d %d %d\n",A[x],IA[x],JA[x]);
            break;


        }
         if(IA1[i]>IA2[j])
        {
            A[x] = A2[j];
            IA[x] = IA2[j];
            JA[x] = JA2[j];

                j++;
            //printf("%d %d %d\n",A[x],IA[x],JA[x]);
            break;

        }
         if(IA1[i] == IA2[j] && JA1[i] == JA2[j])
        {
            A[x] = A1[i] + A2[j];
            IA[x] = IA1[i];
            JA[x] = JA1[i];

                j++;
            i++;
           // printf("%d %d %d\n",A[x],IA[x],JA[x]);
            break;
        }}


        x++;
        if(i == k1 && j==k2)
        {
            indikator = 1;
            break;
        }
         if(i==k1 && j<k2)
        {
            for(int m=j;m<k2;m++)
            {
                A[x] = A2[m];
                IA[x] = IA2[m];
                JA[x] = JA2[m];
               // printf("%d %d %d\n",A[x],IA[x],JA[x]);
                x++;
            }
            indikator = 1;
            break;
        }
         if(i<k1 && j==k2)
        {
            for(int n=i;n<k1;n++)
            {
                A[x] = A1[n];
                IA[x] = IA1[n];
                JA[x] = JA1[n];
               // printf("%d %d %d\n",A[x],IA[x],JA[x]);
                x++;
                 }
            indikator = 1;
            break;       }
            if(i<k1 && j<k2)
            {
                indikator = 0;
            }

}
}


int main(){
    srand(time(0));
int m=500;
int n=500;


create(m,n,mat,90,98);
create(m,n,mat2,90,98);
int k1 = brojJedinica(m,n,mat);
int k2 = brojJedinica(m,n,mat2);
//printf("%d %d\n",k1,k2);
//ispisMat(m,n,mat);
//printf("\n\n\n");
transformToCRS(m,n,mat,A1,IA1,JA1);
//printf("\n\n\n");
//ispisMat(m,n,mat2);
//printf("\n\n\n");
transformToCRS(m,n,mat2,A2,IA2,JA2);
//printf("\n\n\n");


sumaCSR(A1,IA1,JA1,A2,IA2,JA2,A,IA,JA,k1,k2);




return 0;}
