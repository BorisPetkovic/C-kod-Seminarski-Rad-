#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <time.h>

int mat[100][100];
int mat2[100][100];
int A[2000000],IA[2000000],JA[2000000];
int A1[100000],IA1[100000],JA1[100000];
int A2[100000],IA2[100000],JA2[100000];


int randomm(int a,int b)
{
    return (rand()%(b-a+1)+a);
}

void create(int m,int n,int mat[m][n],int procMin,int procMax)
{
int indikator;
float procenat1;
float procenat2;



   int suma = 0;
    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
        mat[i][j] = randomm(0,1);
        if(mat[i][j] == 0){suma++;}
        }


    }

    float procenat = (float)suma / (m*n) *100;


         if(procenat < procMin)
 {   do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 1)
     {
         mat[x][y] = 0;
         suma++;
     }
     procenat1 = (float)suma / (m*n)*100;
 }while(procenat1<procMin);
     }

            if(procenat > procMax)
 {
  do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 0)
     {
         mat[x][y] = 1;
         suma--;
     }
     procenat2 = (float)suma / (m*n)*100;
 }while(procenat2>procMax);
     }
     }

void transformToCRS(int m,int n,int mat[m][n],int A[], int IA[], int JA[])
{   int k =0;

    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(mat[i][j] != 0)
            {
                A[k] = mat[i][j];

                IA[k] = i;
                JA[k] = j;
                k++;

            }
        }
    }

   /* for(int l =0;l<k;l++)
    {
        printf("A[%d]=%d  ",l,A[l]);

    }
    printf("\n");
      for(int l1 =0;l1<k;l1++)
    {
        printf("IA[%d]=%d  ",l1,IA[l1]);

    }
 printf("\n");
      for(int l2 =0;l2<k;l2++)
    {
        printf("JA[%d]=%d  ",l2,JA[l2]);

    }
    printf("\n");*/


}

int brojJedinica(int m,int n,int mat[m][n])
{   int k =0;

    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(mat[i][j] != 0)
            {
                k++;

            }
        }
    }
return k;}


void proizvodCSR(int A1[],int IA1[],int JA1[],int A2[],int IA2[],int JA2[],int A[],int IA[],int JA[],int k1,int k2)
{
    int x = 0;
    for(int i=0;i<k1;i++)
    {
        for(int j=0;j<k2;j++)
        {
            if(JA1[i] == IA2[j])
            {
                A[x] = A1[i] * A2[j];

                IA[x] = IA1[i];
                JA[x] = JA2[j];
                x++;

            }
        }
    }


    /*for(int i1=0;i1<x-1;i1++)
    {
        for(int j1=x-1;j1>i1;j1--)
        {
            if(IA[j1] == IA[j1-1] && JA[j1]<JA[j1-1])
            {
                int temp = A[j1];
                A[j1] = A[j1-1];
                A[j1-1] = temp;

                int temp2 = JA[j1];
                JA[j1] = JA[j1-1];
                JA[j1-1] = temp2;
            }
        }
    }*/



   /* for(int k=x-1;k>0;k--)
    {
        if((IA[k] == IA[k-1]) && (JA[k] == JA[k-1]))
        {
            A[k-1] = A[k] + A[k-1];

            for(int y=k;y<x-1;y++)
            {
                A[y] = A[y+1];
                IA[y] = IA[y+1];
                JA[y] = JA[y+1];




            }
           x--;


        }
    }*/

  /*for(int l=0;l<x;l++)
    {
        printf("%d %d %d\n",A[l],IA[l],JA[l]);
    }*/



}



int main(){
    srand(time(0));
int m=100;
int n=100;


create(m,n,mat,90,98);
create(m,n,mat2,90,98);
int k1 = brojJedinica(m,n,mat);
int k2 = brojJedinica(m,n,mat2);
//printf("%d %d\n",k1,k2);
//ispisMat(m,n,mat);
//printf("\n");
transformToCRS(m,n,mat,A1,IA1,JA1);
//printf("\n\n\n\n");
//ispisMat(m,n,mat2);
//printf("\n");
transformToCRS(m,n,mat2,A2,IA2,JA2);
//printf("\n");


proizvodCSR(A1,IA1,JA1,A2,IA2,JA2,A,IA,JA,k1,k2);



return 0;}
