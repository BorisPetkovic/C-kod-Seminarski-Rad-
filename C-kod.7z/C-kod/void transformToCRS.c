  #include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <time.h>
int randomm(int a,int b)
{
    return (rand()%(b-a+1)+a);
}

void create(int m,int n,int mat[m][n],int procMin,int procMax)
{srand ( time(0));
int indikator;
float procenat1;
float procenat2;



   int suma = 0;
    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
        mat[i][j] = randomm(0,1);
        if(mat[i][j] == 0){suma++;}
        }


    }

    float procenat = (float)suma / (m*n) *100;


         if(procenat < procMin)
 {   do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 1)
     {
         mat[x][y] = 0;
         suma++;
     }
     procenat1 = (float)suma / (m*n)*100;
 }while(procenat1<procMin);
     }

            if(procenat > procMax)
 {
  do{
     int x = randomm(0,m);
     int y = randomm(0,n);
     if(mat[x][y] == 0)
     {
         mat[x][y] = 1;
         suma--;
     }
     procenat2 = (float)suma / (m*n)*100;
 }while(procenat2>procMax);
     }
     }


void transformToCRS(int m,int n,int mat[m][n],int A[], int IA[], int JA[])
{   int k =0;

    for(int i =0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(mat[i][j] != 0)
            {
                A[k] = mat[i][j];

                IA[k] = i;
                JA[k] = j;
                k++;

            }
        }
    }

    for(int l =0;l<k;l++)
    {
        printf("A[%d]=%d  ",l,A[l]);

    }
    printf("\n");
      for(int l1 =0;l1<k;l1++)
    {
        printf("IA[%d]=%d  ",l1,IA[l1]);

    }
 printf("\n");
      for(int l2 =0;l2<k;l2++)
    {
        printf("JA[%d]=%d  ",l2,JA[l2]);

    }
    printf("\n");


}

void ispisMat(int m,int n,int mat[m][n])
{
    for(int i =0;i<m;i++){
        for(int j=0;j<n;j++){
          printf("%d  ",mat[i][j]);

        }
        printf("\n");
    }

}
int main(){

int m=4;
int n=5;
int mat[m][n];
int A[15],IA[15],JA[15];
create(m,n,mat,40,50);
transformToCRS(m,n,mat,A,IA,JA);
printf("\n");
ispisMat(m,n,mat);



return 0;}

